/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javafx.beans.value.ObservableValue;

/**
 *
 * @author danmo
 */
public interface Observable_Vendor extends Vendor {
    public ObservableValue<String> vidProperty();
    public ObservableValue<String> nameProperty();
}
