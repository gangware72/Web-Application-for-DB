package model;

public interface Polo
{
	public String getBrand();
	public String getSize();
	public String getFit();
	public String getColor();
	public String getSKU();
}