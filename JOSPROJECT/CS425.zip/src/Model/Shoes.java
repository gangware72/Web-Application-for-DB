/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author danmo
 */
public interface Shoes {
    public String getBrand();
    public String getLength();
    public String getWidth();
    public String getColor();
    public String getSKU();
    
}
